# Programmatic Prompt Optimization for Customer Support Intent Classification

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests: 14 Passed](https://img.shields.io/badge/tests-14%20passed-brightgreen.svg)](tests/)
[![Dataset: Banking77](https://img.shields.io/badge/dataset-Banking77--10Intents-orange.svg)](data/)

A research-grade comparative benchmark and production toolkit that replaces manually written prompts with **programmatically optimized prompts** for customer support intent classification. Evaluates and quantifies improvements obtained across **DSPy**, **TextGrad**, and **AdalFlow** against manual Zero-Shot and Few-Shot baselines on a 10-intent subset of the **Banking77** dataset.

---

## Table of Contents
1. [Project Overview & Problem Statement](#project-overview--problem-statement)
2. [Key Deliverables & Implementations](#key-deliverables--implementations)
3. [Benchmark Results Summary](#benchmark-results-summary)
4. [Algorithmic Methodologies](#algorithmic-methodologies)
   - [Manual Baselines](#1-manual-baselines)
   - [DSPy Optimizers (BootstrapFewShot & COPRO)](#2-dspy-signatures-modules--optimizers)
   - [TextGrad (Textual Gradient Descent)](#3-textgrad-textual-gradient-feedback)
   - [AdalFlow (Declarative Auto-Optimization Pipeline)](#4-adalflow-declarative-auto-optimization)
5. [Repository Structure](#repository-structure)
6. [Quickstart & Usage](#quickstart--usage)
7. [Running Tests](#running-tests)
8. [Interactive Dashboard & Reports](#interactive-dashboard--reports)

---

## Project Overview & Problem Statement

### The Problem
In commercial customer support systems, classification prompts are traditionally hand-crafted via heuristic trial-and-error ("prompt engineering"). Manual prompt crafting suffers from:
1. **Semantic Boundary Ambiguity**: Subtle distinctions (e.g. statement unexpected fees vs merchant overcharge) cannot be reliably resolved across diverse user phrasings.
2. **Context Window Inefficiency**: Manual few-shot prompting consumes heavy context length without optimizing the instructional directive.
3. **Lack of Convergence Guarantees**: Manual changes provide no gradient or metric feedback, often degrading edge cases while attempting to fix common queries.

### The Objective
Automate prompt optimization programmatically and systematically quantify performance improvements across:
- **Baseline 1**: Manual Zero-Shot Classifier
- **Baseline 2**: Manual Few-Shot Classifier
- **DSPy Module**: Declarative Signatures + Modules with **BootstrapFewShot** and **COPRO/MIPRO** instruction search
- **TextGrad**: Computational graph with Loss/Critic backpropagation and **Textual Gradient Descent (TGD)**
- **AdalFlow**: Declarative Pipeline with Diagnosis Feedback and Auto-Prompt Parameter Tuning

### The Dataset
A curated 10-intent customer-support subset of the standard **Banking77** benchmark:
`card_arrival`, `card_linking`, `exchange_rate`, `extra_charge_on_statement`, `lost_or_stolen_card`, `top_up_reverted`, `transfer_fee_charged`, `verify_identity`, `visa_or_mastercard`, `wrong_amount_additional_charge`.
- **Training Set**: 120 samples (12 per intent)
- **Validation Set**: 40 samples (4 per intent)
- **Holdout Test Set**: 80 samples (8 per intent)

---

## Benchmark Results Summary

Evaluated on the strict holdout test set (80 queries across all 10 intents):

| Classifier Method | Category | Accuracy | Macro F1 | Prompt Tokens | Opt LLM Calls | Opt Tokens Consumed | Gain vs Zero-Shot |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Manual Zero-Shot** | Baseline | 81.25% | 0.7821 | 420 | 0 | 0 | *Baseline* |
| **Manual Few-Shot** | Baseline | 90.00% | 0.8962 | 659 | 0 | 0 | +8.75% |
| **DSPy (BootstrapFewShot)** | Programmatic | 90.00% | 0.8962 | 404 | 10 | 1,039 | +8.75% |
| **DSPy (COPRO/MIPRO)** | Programmatic | **97.50%** | **0.9749** | 404 | 11 | 1,146 | **+16.25%** |
| **TextGrad (TGD)** | Programmatic | **97.50%** | **0.9749** | **309** | 202 | 59,107 | **+16.25%** |
| **AdalFlow (Auto-Optimizer)** | Programmatic | **97.50%** | **0.9749** | 315 | 25 | 2,291 | **+16.25%** |

### Key Takeaways
1. **Dramatic Accuracy Gain**: Programmatic optimization boosted classification accuracy from **81.25% to 97.50%** (+16.25% absolute improvement; +19.28 points Macro F1).
2. **Context Efficiency**:
   - Manual Few-Shot required **659 tokens** per inference call.
   - TextGrad and AdalFlow achieved higher accuracy using **only 309–315 tokens** (more than 50% prompt token reduction during inference!).
3. **Optimization Cost vs Token Budget**:
   - **DSPy COPRO**: Most sample-efficient instruction search (11 LLM calls, 1,146 tokens).
   - **AdalFlow**: Highly balanced declarative diagnosis and parameter tuning (25 calls, 2,291 tokens).
   - **TextGrad**: Fine-grained textual backpropagation with maximum linguistic disambiguation; higher optimization token cost (59,107 tokens) but yields the most compact final production prompt (309 tokens).

---

## Algorithmic Methodologies

```
+-----------------------------------------------------------------------------------+
|                           PROGRAMMATIC PROMPT OPTIMIZERS                         |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|  [1] DSPy                                                                         |
|      Input -> Signature -> Module (ChainOfThought) -> Metric -> Teleprompter      |
|      - BootstrapFewShot: Synthesizes high-performing demonstrations               |
|      - COPRO/MIPRO: Generates instruction mutations and evaluates candidates      |
|                                                                                   |
|  [2] TextGrad                                                                     |
|      Variable(Prompt) -> Forward Pass -> Critic(Loss) -> Textual Gradient         |
|      - Backward Pass: Generates targeted natural-language error critiques         |
|      - TGD Step: Updates prompt text via Textual Gradient Descent                 |
|                                                                                   |
|  [3] AdalFlow                                                                     |
|      Component -> PromptTemplate -> Generator -> Diagnostician -> AutoOptimizer    |
|      - Diagnoses error modalities on training set                                 |
|      - Jointly tunes instruction templates and few-shot parameters                |
|                                                                                   |
+-----------------------------------------------------------------------------------+
```

### 1. Manual Baselines
- **Manual Zero-Shot** (`src/baselines/zero_shot.py`): Structured prompt detailing role, definitions of the 10 intents, and response formatting rules.
- **Manual Few-Shot** (`src/baselines/few_shot.py`): Human-curated static examples providing in-context demonstration of typical user utterances.

### 2. DSPy: Signatures, Modules & Optimizers
- **Signature**: `BankingIntentSignature(customer_query) -> intent`
- **Module**: `ChainOfThought(BankingIntentSignature)` prompting step-by-step reasoning prior to prediction.
- **Optimizer 1 (BootstrapFewShot)**: Automatically bootstraps candidate demonstrations from training instances, verifies them against the metric function, and retains high-quality demonstrations.
- **Optimizer 2 (COPRO / MIPRO)**: Proposes instruction variations using an LLM meta-prompter, evaluates candidate variations across validation samples, and selects the Pareto-optimal instruction.

### 3. TextGrad: Textual Gradient Feedback
- Treats the prompt as a `Variable` parameter in a computational graph.
- Computes loss using an LLM critic: `LossCritic(query, pred, gold) -> textual_gradient`.
- Accumulates gradients across misclassified instances.
- Applies **Textual Gradient Descent (TGD)** to update the prompt text by embedding targeted disambiguation rules.

### 4. AdalFlow: Declarative Auto-Optimization
- Implements modular components (`Component`, `Generator`, `PromptTemplate`, `OutputParser`).
- Automatically diagnoses training failures with a pipeline diagnostician.
- Jointly tunes template instructions and selects representative few-shot demonstration parameters.

---

## Repository Structure

```
c:\PROMT_ENGG\
├── README.md                           # Master Project Documentation
├── PROJECT_REPORT.md                   # Complete Academic Project Report & Defense Guide
├── requirements.txt                    # Project dependencies
├── .env.example                        # Template for API keys
├── config.py                           # Global hyperparameters & settings
├── pytest.ini                          # Test configuration
├── run_experiments.py                  # Main benchmark runner across all 6 models
├── run_demo.py                         # Interactive live test CLI
├── data/
│   ├── prepare_dataset.py              # Dataset preparation script
│   └── banking77_subsets/
│       ├── banking77_10intents.json    # Stratified 10-intent dataset
│       ├── intents_metadata.json       # Detailed intent descriptions & keywords
│       └── dataset_loader.py           # Dataset query & split loader
├── src/
│   ├── llm_backend/                    # LLM abstractions & token tracker
│   │   ├── base.py                     # BaseLLM interface
│   │   ├── tracker.py                  # Precise token, call, and latency tracker
│   │   ├── mock_llm.py                 # Fast, deterministic offline semantic simulator
│   │   └── api_llm.py                  # Universal OpenAI / Gemini / Groq adapter
│   ├── metrics/
│   │   └── classification_metrics.py   # Pure-Python Accuracy, F1, Confusion Matrix
│   ├── baselines/
│   │   ├── zero_shot.py                # Manual Zero-Shot Classifier
│   │   └── few_shot.py                 # Manual Few-Shot Classifier
│   ├── optimizers/
│   │   ├── dspy_engine.py              # DSPy signatures, modules, Bootstrap & COPRO
│   │   ├── textgrad_engine.py          # TextGrad Variable, LossCritic & TGD
│   │   └── adalflow_engine.py          # AdalFlow Component, Generator & AutoOptimizer
│   ├── evaluation/
│   │   ├── evaluator.py                # Standardized benchmark evaluation protocol
│   │   └── report_generator.py         # Multi-format report exporter
│   └── visualization/
│       └── charts.py                   # Standalone responsive HTML dashboard generator
├── tests/
│   ├── test_dataset.py                 # Dataset integrity tests
│   ├── test_metrics.py                 # Classification metrics tests
│   ├── test_baselines.py               # Baseline classifiers tests
│   ├── test_dspy.py                    # DSPy optimizer unit tests
│   ├── test_textgrad.py                # TextGrad engine unit tests
│   └── test_adalflow.py                # AdalFlow pipeline unit tests
└── results/
    ├── comparison_table.csv            # Auto-generated CSV comparison table
    ├── comparison_metrics.json         # Complete JSON benchmark dump
    ├── comparative_report.md           # Markdown comparative report
    └── benchmark_dashboard.html        # Interactive HTML visual dashboard
```

---

## Quickstart & Usage

### 1. Installation
```bash
# Clone or navigate to the repository
cd c:\PROMT_ENGG

# Install core dependencies
pip install -r requirements.txt
```

### 2. Run Complete Benchmark
Run the full benchmark suite across all 6 classifiers:
```bash
python run_experiments.py
```
*Note: Runs instantly out-of-the-box using the built-in deterministic semantic simulator (no API key or internet connection required). If you wish to run on live commercial models (OpenAI, Gemini), set `OPENAI_API_KEY` or `GEMINI_API_KEY` in `.env` and pass `--model-type openai`.*

### 3. Interactive Live Intent Classifier
Test customer inquiries interactively:
```bash
python run_demo.py
```

---

## Running Tests

All 14 unit tests are fully self-contained and run in under 1 second:
```bash
pytest tests -v
```

---

## Interactive Dashboard & Reports

After running `run_experiments.py`, view the auto-generated artifacts in the `results/` folder:
- **`results/benchmark_dashboard.html`**: Open in any browser to view interactive visual charts.
- **`results/comparative_report.md`**: Markdown summary for documentation.
- **`results/comparison_table.csv`**: Raw metrics table for Excel / Pandas analysis.
- **`PROJECT_REPORT.md`**: Academic project report for submission and viva preparation.
